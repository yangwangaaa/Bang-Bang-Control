function cost = VDP_costc(u)
cost = u(end);
end