function cost = VDP_costb(u)
cost = u(end);
end