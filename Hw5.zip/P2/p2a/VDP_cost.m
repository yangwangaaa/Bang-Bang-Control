function cost = VDP_cost(u)
cost = u(end);
end