
function cost = p1c_cost(u)
cost = u(end);
end