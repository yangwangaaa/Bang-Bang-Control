function cost = p1_cost(u)
cost = u(end);
end