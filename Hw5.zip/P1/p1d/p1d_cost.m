function cost = p1d_cost(u)
cost = u(end);
end