
function cost = p1b_cost(u)
cost = u(end);
end